VoicePlayer 1.2.0 for macOS
===========================
1. Double-click "VoicePlayer-macOS-Installer.command" to install VoicePlayer.
2. If macOS displays a Gatekeeper warning:
   Right-click (or Control-click) "VoicePlayer-macOS-Installer.command" and choose "Open".
3. After installation, VoicePlayer will launch automatically and can be found in ~/Applications/VoicePlayer.command.
